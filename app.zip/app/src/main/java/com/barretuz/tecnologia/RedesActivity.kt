package com.barretuz.tecnologia

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RedesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_redes)

        val btnVoltar = findViewById<Button>(R.id.btnVoltar)
        val btnComprarRede1 = findViewById<Button>(R.id.btnComprarRede1)
        val btnComprarRede2 = findViewById<Button>(R.id.btnComprarRede2)

        btnVoltar.setOnClickListener { finish() }

        btnComprarRede1.setOnClickListener {
            CarrinhoManager.adicionarItem("Switch Gigabit 24 Portas", 1250.0)
            Toast.makeText(this, "Switch adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
        }

        btnComprarRede2.setOnClickListener {
            CarrinhoManager.adicionarItem("Access Point Wi-Fi 6", 890.0)
            Toast.makeText(this, "Access Point adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
        }
    }
}