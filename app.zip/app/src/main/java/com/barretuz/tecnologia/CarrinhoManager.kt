package com.barretuz.tecnologia

object CarrinhoManager {
    val itens = mutableListOf<Pair<String, Double>>()

    fun adicionarItem(nome: String, preco: Double) {
        itens.add(Pair(nome, preco))
    }

    fun calcularTotal(): Double {
        var total = 0.0
        for (item in itens) {
            total += item.second
        }
        return total
    }

    fun limparCarrinho() {
        itens.clear()
    }
}