package com.barretuz.tecnologia

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SoftwareActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_software)

        val btnVoltar = findViewById<Button>(R.id.btnVoltar)
        val btnComprarSoft1 = findViewById<Button>(R.id.btnComprarSoft1)
        val btnComprarSoft2 = findViewById<Button>(R.id.btnComprarSoft2)

        btnVoltar.setOnClickListener { finish() }

        btnComprarSoft1.setOnClickListener {
            CarrinhoManager.adicionarItem("Site Institucional / E-commerce", 1500.0)
            Toast.makeText(this, "Site Institucional adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
        }

        btnComprarSoft2.setOnClickListener {
            CarrinhoManager.adicionarItem("Aplicativo Mobile Nativo", 2800.0)
            Toast.makeText(this, "Aplicativo Mobile adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
        }
    }
}