package com.barretuz.tecnologia

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ManutencaoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manutencao)

        val btnVoltar = findViewById<Button>(R.id.btnVoltar)
        val btnComprarManut1 = findViewById<Button>(R.id.btnComprarManut1)
        val btnComprarManut2 = findViewById<Button>(R.id.btnComprarManut2)

        btnVoltar.setOnClickListener { finish() }

        btnComprarManut1.setOnClickListener {
            CarrinhoManager.adicionarItem("Reparo SSD/RAM", 180.0)
            Toast.makeText(this, "Reparo SSD/RAM adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
        }

        btnComprarManut2.setOnClickListener {
            CarrinhoManager.adicionarItem("Manutenção de Placas e Fontes", 350.0)
            Toast.makeText(this, "Manutenção de Placas adicionada ao carrinho!", Toast.LENGTH_SHORT).show()
        }
    }
}