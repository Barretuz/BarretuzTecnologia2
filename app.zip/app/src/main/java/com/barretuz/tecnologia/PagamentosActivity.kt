package com.barretuz.tecnologia

import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class PagamentosActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Corrigido para apontar exatamente para activity_pagamentos.xml (com 's')
        setContentView(R.layout.activity_pagamentos)

        val txtTotal = findViewById<TextView>(R.id.txtTotalPagamento)
        val radioPix = findViewById<RadioButton>(R.id.radioPix)
        val btnConfirmar = findViewById<Button>(R.id.btnConfirmarPagamento)
        val btnVoltar = findViewById<Button>(R.id.btnVoltarCarrinho)

        val total = CarrinhoManager.calcularTotal()
        txtTotal.text = "Total a Pagar: R$ %.2f".format(total)

        btnConfirmar.setOnClickListener {
            val metodo = if (radioPix.isChecked) "PIX" else "Boleto Bancário"
            Toast.makeText(this, "Pedido realizado com sucesso via $metodo!", Toast.LENGTH_LONG).show()
            CarrinhoManager.limparCarrinho()
            finishAffinity()
        }

        btnVoltar.setOnClickListener {
            finish()
        }
    }
}