package com.barretuz.tecnologia

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CarrinhoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_carrinho)

        atualizarCarrinho()

        val btnIrPagamento = findViewById<Button>(R.id.btnFinalizarPedido)
        val btnVoltar = findViewById<Button>(R.id.btnVoltarLoja)

        btnIrPagamento.setOnClickListener {
            if (CarrinhoManager.itens.isEmpty()) {
                Toast.makeText(this, "O seu carrinho está vazio!", Toast.LENGTH_SHORT).show()
            } else {
                // Corrigido para PagamentosActivity (com 's', correspondendo ao seu ficheiro)
                val intent = Intent(this, PagamentosActivity::class.java)
                startActivity(intent)
            }
        }

        btnVoltar.setOnClickListener {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        atualizarCarrinho()
    }

    private fun atualizarCarrinho() {
        val txtItens = findViewById<TextView>(R.id.txtItensCarrinho)
        val txtTotal = findViewById<TextView>(R.id.txtValorTotal)

        if (CarrinhoManager.itens.isEmpty()) {
            txtItens.text = "Nenhum item adicionado ainda."
            txtTotal.text = "R$ 0,00"
        } else {
            val sb = StringBuilder()
            for (item in CarrinhoManager.itens) {
                sb.append("• ${item.first} - R$ %.2f\n".format(item.second))
            }
            txtItens.text = sb.toString()
            txtTotal.text = "R$ %.2f".format(CarrinhoManager.calcularTotal())
        }
    }
}