package com.barretuz.tecnologia

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnIrCarrinho = findViewById<Button>(R.id.btnIrCarrinho)
        val btnIrRedes = findViewById<Button>(R.id.btnIrRedes)
        val btnIrManutencao = findViewById<Button>(R.id.btnIrManutencao)
        val btnIrSoftware = findViewById<Button>(R.id.btnIrSoftware)

        btnIrCarrinho.setOnClickListener {
            startActivity(Intent(this, CarrinhoActivity::class.java))
        }

        btnIrRedes.setOnClickListener {
            startActivity(Intent(this, RedesActivity::class.java))
        }

        btnIrManutencao.setOnClickListener {
            startActivity(Intent(this, ManutencaoActivity::class.java))
        }

        btnIrSoftware.setOnClickListener {
            startActivity(Intent(this, SoftwareActivity::class.java))
        }
    }
}